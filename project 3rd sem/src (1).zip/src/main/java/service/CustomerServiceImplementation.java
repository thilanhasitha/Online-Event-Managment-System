package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Customer;

public class CustomerServiceImplementation implements CustomerService{

	@Override
	public Customer insertCustomer(Customer cus) {
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project1", "root", "OOPproject@21");
			
			PreparedStatement stmt = con.prepareStatement("INSERT INTO customer(ID,Name,Email,PhoneNo,userName,password) VALUES (?,?,?,?,?,?)");
			
			//PreparedStatement stmt = con.prepareStatement("INSERT INTO customer(Name,Email,PhoneNo,userName,password) VALUES ('"+cus.getName()+"','"+cus.getEmail()+"','"+cus.getpNumber()+"','"+cus.getUserName()+"','"+cus.getPassword()+"'");
			
			stmt.setInt(1, cus.getCusID());
			stmt.setString(2, cus.getName());
			stmt.setString(3, cus.getEmail());
			stmt.setString(4, cus.getpNumber());
			stmt.setString(5, cus.getUserName());
			stmt.setString(6, cus.getPassword());
			
			stmt.executeUpdate();
			
			con.commit();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return cus;
	}

	@Override
	public List<Customer> validate(String uName, String uPassword) {
		ArrayList<Customer> cus = new ArrayList<Customer>();
		
		//database connection
		String url = "jdbc:mysql://localhost:3306/project1";
		String user = "root";
		String pass = "OOPproject@21";
		
		//validation
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url,user,pass);
			PreparedStatement stmt = con.prepareStatement("SELECT * FROM customer WHERE userName = '"+uName+"' AND password = '"+uPassword+"'");
			
			ResultSet rs = stmt.executeQuery();
			
			if(rs.next()) {
				int cid = rs.getInt(1);
				String name = rs.getString(2);
				String email = rs.getString(3);
				String pnumber = rs.getString(4);
				String username = rs.getString(5);
				String password = rs.getString(6);
				
				Customer c = new Customer(cid,name,email,pnumber,username,password);
				
				cus.add(c);
				
			}
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
 		
		return cus;
	}

	@Override
	public Customer updateCustomer(Customer cus) {
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project1", "root", "OOPproject@21");
			PreparedStatement stmt = con.prepareStatement("UPDATE customer SET Name = '"+cus.getName()+"' Email = '"+cus.getEmail()+"' PhoneNo = '"+cus.getpNumber()+"' userName = '"+cus.getUserName()+"' password = '"+cus.getPassword()+"'");
			
			stmt.setString(1, cus.getName());
			stmt.setString(2, cus.getEmail());
			stmt.setString(3, cus.getpNumber());
			stmt.setString(4, cus.getUserName());
			stmt.setString(5, cus.getPassword());
			
			stmt.executeUpdate();
			
			con.commit();
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return cus;
	}
	

	@Override
	public Customer deleteCustomer(Customer cus) {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project1", "root", "OOPproject@21");
			PreparedStatement stmt = con.prepareStatement("DELETE FROM customer WHERE ID = '"+cus.getCusID()+"'");
			
			stmt.setInt(1,cus.getCusID());
			
			stmt.executeUpdate();
			
			con.commit();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return cus;
	}

	@Override
	public boolean deleteCustomer(int cusID) {
		
		Connection con = null;
		boolean isSuccess = false;
		
		try { Class.forName("com.mysql.jdbc.Driver");
		  
		  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project1", "root", "OOPproject@21");
		  
		  Statement pst = con.createStatement();
		  
		  String sql = "DELETE FROM customer WHERE ID = '"+cusID+"'";
		  
		  int rs = pst.executeUpdate(sql);
		  
		  if(rs>0) {
			  
			  isSuccess = true;
		  }
		  else {
			  isSuccess = false;
		  }
		  
		  }
		  catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  return isSuccess;
	}

	
}
