package service;

import java.util.List;

import model.Customer;

public interface CustomerService {
	
	public Customer insertCustomer(Customer cus);
	public List<Customer> validate(String uName,String uPassword);
	public Customer updateCustomer(Customer cus);
	public Customer deleteCustomer(Customer cus);
	public boolean deleteCustomer(int cusID);

}
