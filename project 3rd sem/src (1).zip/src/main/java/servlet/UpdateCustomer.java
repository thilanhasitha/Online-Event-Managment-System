package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Customer;
import service.CustomerServiceImplementation;

/**
 * Servlet implementation class UpdateCustomer
 */
@WebServlet("/UpdateCustomer")
public class UpdateCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//boolean isSuccess;
		
		String uname = request.getParameter("uName");
		String uemail = request.getParameter("uEmail");
		String uPhone = request.getParameter("uPhoneNo");
		String uUsername = request.getParameter("uUsername");
		String uPassword = request.getParameter("uPassword");
		
		Customer cus = new Customer(uname,uemail,uPhone,uUsername,uPassword);
		CustomerServiceImplementation csImplementation = new CustomerServiceImplementation();
		
		ArrayList<Customer> cusDetails = new ArrayList<Customer>();
		
		//isSuccess = Boolean.valueOf(csImplementation.updateCustomer(cus).toString());
		
		csImplementation.updateCustomer(cus);
		cusDetails.add(cus);
		
		request.setAttribute("cusDetails", cusDetails);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);
		
//		if(isSuccess==true) {
//			RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
//			dispatcher.forward(request, response);
//		}
//		else {
//			RequestDispatcher dispatcher = request.getRequestDispatcher("/updateUser.jsp");
//			dispatcher.forward(request, response);
//		}
	}

}
