package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Customer;
import service.CustomerServiceImplementation;

/**
 * Servlet implementation class DeleteCustomer
 */
@WebServlet("/DeleteCustomer")
public class DeleteCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int uid = Integer.valueOf(request.getParameter("uid"));
		
		boolean istrue;
		/*
		 * Customer cus = new Customer(uid); CustomerServiceImplementation
		 * csImplementation = new CustomerServiceImplementation();
		 * csImplementation.deleteCustomer(cus);
		 * 
		 * RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp");
		 * dispatcher.forward(request, response);
		 */
		
		Customer cus = new Customer(uid);
		
		cus.setCusID(uid);
		
		CustomerServiceImplementation csImplementation = new CustomerServiceImplementation();
		istrue = csImplementation.deleteCustomer(uid);
		
		
		
		if(istrue==true) {
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/register.jsp");
			dispatcher.forward(request, response);
		}
		else {
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/deleteUser.jsp");
			dispatcher.forward(request, response);
		}
	}

}
