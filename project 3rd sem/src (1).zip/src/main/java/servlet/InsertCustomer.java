package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Customer;
import service.CustomerServiceImplementation;

/**
 * Servlet implementation class InsertCustomer
 */
@WebServlet("/InsertCustomer")
public class InsertCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//boolean isSuccess;
		
		//Integer uid = Integer.valueOf(getParameter("cid"));
		//int uid = Integer.valueOf(request.getParameter("cid"));
		String uname = request.getParameter("cname");
		String uemail = request.getParameter("cemail");
		String upnumber = request.getParameter("cpNo");
		String uUsername = request.getParameter("cusername");
		String upass = request.getParameter("cpassword");
		
		Customer cus = new Customer(uname,uemail,upnumber,uUsername,upass);
		CustomerServiceImplementation csImplementation = new CustomerServiceImplementation();
		//isSuccess = String.valueOf(Customer).csImplementation.insertCustomer(cus);
		//isSuccess = (boolean).csImplementation.insertCustomer(cus);
		
		csImplementation.insertCustomer(cus);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
		dispatcher.forward(request, response);
		
		
		//casting boolean to string
//		isSuccess = Boolean.valueOf(csImplementation.insertCustomer(cus).toString());
//		
//		
//		if(isSuccess== true) {
//			RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
//			dispatcher.forward(request, response);
//		}
//		else {
//			RequestDispatcher dispatcher = request.getRequestDispatcher("/register.jsp");
//			dispatcher.forward(request, response);
//		}
		
		
	}

}
