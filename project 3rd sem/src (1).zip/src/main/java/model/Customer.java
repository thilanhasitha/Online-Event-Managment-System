package model;

public class Customer {
	
	private int cusID;
	private String name;
	private String email;
	private String pNumber;
	private String userName;
	private String password;
	
	

	public Customer(int cusID) {
		super();
		this.cusID = cusID;
	}



	public Customer(int cusID, String name, String email, String pNumber, String userName, String password) {
		super();
		this.cusID = cusID;
		this.name = name;
		this.email = email;
		this.pNumber = pNumber;
		this.userName = userName;
		this.password = password;
	}
	
	

	public Customer(String name, String email, String pNumber, String userName, String password) {
		super();
		this.name = name;
		this.email = email;
		this.pNumber = pNumber;
		this.userName = userName;
		this.password = password;
	}



	public int getCusID() {
		return cusID;
	}

	public void setCusID(int cusID) {
		this.cusID = cusID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getpNumber() {
		return pNumber;
	}

	public void setpNumber(String pNumber) {
		this.pNumber = pNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	
	
	
	

}
